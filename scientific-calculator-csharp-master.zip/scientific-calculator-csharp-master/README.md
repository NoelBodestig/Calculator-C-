# The scientific calculator on C&#35;

<a href="https://pic.co.ua/image/ufP"><img  align="left" src="https://pic.co.ua/images/2015/10/22/753a2b52426e795ed3ed0ece752e7177.md.jpg" border="0"  ></a> 
<p>The scientific calculator on C# (Microsoft Visual Studio 2013) with GUI. based on Reverse Polish Notation.</p>
Files:<br>
<ul>
 <li>Form1.cs - GUI of calculator</li>
 <li>Program.cs - initialization</li>
 <li>Class1.cs - class RPN with to private methods(GetExpression(input2rpn) and Counting(rpn2result)) and one public method (Calculate (input2result)), many additional static methods and classes of my own Exceptions</li>
</ul>
